"""
document_reader.py
------------------
Robust PDF document extraction, validation, and metadata processing
using `pypdf`. Designed specifically for the AI Document Comparison Assistant.

Features:
- Validates file type, header signature, size, and corruption.
- Detects password-protected / encrypted PDFs with clear messages.
- Extracts text with page-level traceability (page numbers retained).
- Detects scanned/image-only PDFs (no OCR pretence; gives honest warnings).
- Checks text length against model context window limits.
- Generates clean text previews and statistics for UI presentation.
"""

from dataclasses import dataclass, field
import hashlib
import io
import os
from typing import List, Optional, Tuple
import pypdf
from pypdf.errors import PdfReadError


@dataclass
class ExtractedPage:
    """Represents text extracted from a single PDF page."""
    page_number: int  # 1-indexed
    text: str
    char_count: int
    word_count: int
    is_readable: bool


@dataclass
class DocumentMetadata:
    """Detailed summary and extraction status of an uploaded document."""
    filename: str
    file_size_bytes: int
    file_size_formatted: str
    total_pages: int
    readable_pages_count: int
    unreadable_pages_count: int
    total_characters: int
    total_words: int
    estimated_tokens: int
    content_hash: str = ""
    pages: List[ExtractedPage] = field(default_factory=list)
    combined_text: str = ""
    is_valid: bool = False
    is_encrypted: bool = False
    is_scanned_or_image_only: bool = False
    error_message: Optional[str] = None
    warnings: List[str] = field(default_factory=list)

    def get_preview(self, max_chars: int = 600) -> str:
        """Returns a trimmed preview of the extracted text."""
        clean = self.combined_text.strip()
        if not clean:
            return "(No text extracted)"
        if len(clean) <= max_chars:
            return clean
        return clean[:max_chars].rstrip() + "... [more content available]"

    def get_page_text_with_markers(self) -> str:
        """
        Formats the combined text with explicit page markers for LLM traceability:
        e.g., [Page 1]
              text...
        """
        formatted_blocks = []
        for p in self.pages:
            if p.text.strip():
                formatted_blocks.append(f"--- [Page {p.page_number}] ---\n{p.text.strip()}")
        return "\n\n".join(formatted_blocks)


def format_file_size(size_bytes: int) -> str:
    """Formats file size into human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    else:
        return f"{size_bytes / (1024 * 1024):.2f} MB"


class PDFExtractionError(Exception):
    """Custom exception for PDF extraction issues."""
    pass


# Module-level extraction cache keyed by (content_hash, password)
_EXTRACTION_CACHE: dict = {}


def extract_and_validate_pdf(
    file_source: io.BytesIO | bytes | str,
    filename: str = "document.pdf",
    password: Optional[str] = None,
    max_token_budget: int = 500_000,
) -> DocumentMetadata:
    """
    Extracts text from a PDF, validates its content, and generates document metrics.
    Caches results using SHA-256 content hash to prevent redundant parsing.

    Args:
        file_source: In-memory bytes, BytesIO buffer, or local file path.
        filename: Name of the uploaded file.
        password: Optional password for encrypted files.
        max_token_budget: Safe upper limit for LLM context window.

    Returns:
        DocumentMetadata instance with extraction results and validation status.
    """
    # 1. Read bytes
    if isinstance(file_source, str):
        if not os.path.exists(file_source):
            return DocumentMetadata(
                filename=filename,
                file_size_bytes=0,
                file_size_formatted="0 B",
                total_pages=0,
                readable_pages_count=0,
                unreadable_pages_count=0,
                total_characters=0,
                total_words=0,
                estimated_tokens=0,
                content_hash="",
                is_valid=False,
                error_message=f"File not found: {file_source}",
            )
        with open(file_source, "rb") as f:
            pdf_bytes = f.read()
    elif isinstance(file_source, io.BytesIO):
        pdf_bytes = file_source.getvalue()
    elif isinstance(file_source, bytes):
        pdf_bytes = file_source
    else:
        # File-like object (e.g. Streamlit UploadedFile)
        try:
            pdf_bytes = file_source.read()
            if hasattr(file_source, "seek"):
                file_source.seek(0)
        except Exception as e:
            return DocumentMetadata(
                filename=filename,
                file_size_bytes=0,
                file_size_formatted="0 B",
                total_pages=0,
                readable_pages_count=0,
                unreadable_pages_count=0,
                total_characters=0,
                total_words=0,
                estimated_tokens=0,
                content_hash="",
                is_valid=False,
                error_message=f"Failed to read file stream: {str(e)}",
            )

    file_size = len(pdf_bytes)
    file_size_str = format_file_size(file_size)

    # 2. Check for empty file
    if file_size == 0:
        return DocumentMetadata(
            filename=filename,
            file_size_bytes=0,
            file_size_formatted="0 B",
            total_pages=0,
            readable_pages_count=0,
            unreadable_pages_count=0,
            total_characters=0,
            total_words=0,
            estimated_tokens=0,
            content_hash="",
            is_valid=False,
            error_message="The uploaded file is empty (0 bytes). Please upload a valid PDF document.",
        )

    # Compute stable content hash
    content_hash = hashlib.sha256(pdf_bytes).hexdigest()
    cache_key = (content_hash, password, max_token_budget)

    # Return cached extraction immediately if already parsed
    if cache_key in _EXTRACTION_CACHE:
        cached = _EXTRACTION_CACHE[cache_key]
        # Return a copy with current filename
        return DocumentMetadata(
            filename=filename,
            file_size_bytes=cached.file_size_bytes,
            file_size_formatted=cached.file_size_formatted,
            total_pages=cached.total_pages,
            readable_pages_count=cached.readable_pages_count,
            unreadable_pages_count=cached.unreadable_pages_count,
            total_characters=cached.total_characters,
            total_words=cached.total_words,
            estimated_tokens=cached.estimated_tokens,
            content_hash=content_hash,
            pages=cached.pages,
            combined_text=cached.combined_text,
            is_valid=cached.is_valid,
            is_encrypted=cached.is_encrypted,
            is_scanned_or_image_only=cached.is_scanned_or_image_only,
            error_message=cached.error_message,
            warnings=cached.warnings,
        )

    # 3. Check PDF header signature (%PDF-)
    if not pdf_bytes.startswith(b"%PDF-"):
        # Some PDFs may have leading whitespace or BOM, check first 1024 bytes
        if b"%PDF-" not in pdf_bytes[:1024]:
            return DocumentMetadata(
                filename=filename,
                file_size_bytes=file_size,
                file_size_formatted=file_size_str,
                total_pages=0,
                readable_pages_count=0,
                unreadable_pages_count=0,
                total_characters=0,
                total_words=0,
                estimated_tokens=0,
                is_valid=False,
                error_message=(
                    f"Invalid file format: '{filename}' does not appear to be a valid PDF document. "
                    "Only PDF files are supported."
                ),
            )

    # 4. Open PDF using pypdf
    stream = io.BytesIO(pdf_bytes)
    try:
        reader = pypdf.PdfReader(stream)
    except PdfReadError as e:
        return DocumentMetadata(
            filename=filename,
            file_size_bytes=file_size,
            file_size_formatted=file_size_str,
            total_pages=0,
            readable_pages_count=0,
            unreadable_pages_count=0,
            total_characters=0,
            total_words=0,
            estimated_tokens=0,
            is_valid=False,
            error_message=f"Corrupted or unreadable PDF: Unable to parse document structure. ({str(e)})",
        )
    except Exception as e:
        return DocumentMetadata(
            filename=filename,
            file_size_bytes=file_size,
            file_size_formatted=file_size_str,
            total_pages=0,
            readable_pages_count=0,
            unreadable_pages_count=0,
            total_characters=0,
            total_words=0,
            estimated_tokens=0,
            is_valid=False,
            error_message=f"Unexpected error opening PDF: {str(e)}",
        )

    # 5. Check encryption / password protection
    if reader.is_encrypted:
        if password:
            try:
                decrypted = reader.decrypt(password)
                if decrypted == 0:
                    return DocumentMetadata(
                        filename=filename,
                        file_size_bytes=file_size,
                        file_size_formatted=file_size_str,
                        total_pages=0,
                        readable_pages_count=0,
                        unreadable_pages_count=0,
                        total_characters=0,
                        total_words=0,
                        estimated_tokens=0,
                        is_valid=False,
                        is_encrypted=True,
                        error_message="Incorrect password for encrypted PDF. Please enter the correct password.",
                    )
            except Exception as e:
                return DocumentMetadata(
                    filename=filename,
                    file_size_bytes=file_size,
                    file_size_formatted=file_size_str,
                    total_pages=0,
                    readable_pages_count=0,
                    unreadable_pages_count=0,
                    total_characters=0,
                    total_words=0,
                    estimated_tokens=0,
                    is_valid=False,
                    is_encrypted=True,
                    error_message=f"Failed to decrypt PDF: {str(e)}",
                )
        else:
            return DocumentMetadata(
                filename=filename,
                file_size_bytes=file_size,
                file_size_formatted=file_size_str,
                total_pages=0,
                readable_pages_count=0,
                unreadable_pages_count=0,
                total_characters=0,
                total_words=0,
                estimated_tokens=0,
                is_valid=False,
                is_encrypted=True,
                error_message=(
                    f"'{filename}' is password-protected/encrypted. "
                    "Please provide an unencrypted PDF or unlock it before comparison."
                ),
            )

    # 6. Check total pages
    total_pages = len(reader.pages)
    if total_pages == 0:
        return DocumentMetadata(
            filename=filename,
            file_size_bytes=file_size,
            file_size_formatted=file_size_str,
            total_pages=0,
            readable_pages_count=0,
            unreadable_pages_count=0,
            total_characters=0,
            total_words=0,
            estimated_tokens=0,
            is_valid=False,
            error_message="The PDF contains 0 pages.",
        )

    # 7. Extract text page by page with traceability
    extracted_pages: List[ExtractedPage] = []
    total_chars = 0
    total_words = 0
    readable_pages = 0
    unreadable_pages = 0
    combined_text_list = []
    warnings: List[str] = []

    for idx, page in enumerate(reader.pages):
        page_num = idx + 1
        try:
            page_text = page.extract_text() or ""
        except Exception as e:
            page_text = ""
            warnings.append(f"Warning: Failed to extract text from page {page_num}: {str(e)}")

        clean_page_text = page_text.strip()
        char_count = len(clean_page_text)
        word_count = len(clean_page_text.split()) if clean_page_text else 0

        is_readable = char_count > 0
        if is_readable:
            readable_pages += 1
            combined_text_list.append(clean_page_text)
        else:
            unreadable_pages += 1

        total_chars += char_count
        total_words += word_count

        extracted_pages.append(
            ExtractedPage(
                page_number=page_num,
                text=clean_page_text,
                char_count=char_count,
                word_count=word_count,
                is_readable=is_readable,
            )
        )

    combined_text = "\n\n".join(combined_text_list)
    estimated_tokens = int(total_chars / 4)  # rule of thumb for English text

    # 8. Check for scanned / image-only PDF
    # If the document has pages but zero text, or average text per page < 15 characters
    is_scanned = False
    if total_pages > 0 and (total_chars == 0 or (total_chars / total_pages) < 15):
        is_scanned = True
        error_msg = (
            f"No readable text could be extracted from '{filename}'. "
            "This document appears to be a scanned document or image-only PDF. "
            "Note: Optical Character Recognition (OCR) is not performed by this text extractor. "
            "Please upload a text-searchable PDF."
        )
        meta_scanned = DocumentMetadata(
            filename=filename,
            file_size_bytes=file_size,
            file_size_formatted=file_size_str,
            total_pages=total_pages,
            readable_pages_count=readable_pages,
            unreadable_pages_count=unreadable_pages,
            total_characters=total_chars,
            total_words=total_words,
            estimated_tokens=estimated_tokens,
            content_hash=content_hash,
            pages=extracted_pages,
            combined_text="",
            is_valid=False,
            is_scanned_or_image_only=True,
            error_message=error_msg,
            warnings=warnings,
        )
        _EXTRACTION_CACHE[cache_key] = meta_scanned
        return meta_scanned

    # 9. Check if some pages were unreadable
    if unreadable_pages > 0:
        warnings.append(
            f"{unreadable_pages} of {total_pages} pages contained no extractable text "
            "(they may be blank, contain images, or require OCR)."
        )

    # 10. Check context length budget
    if estimated_tokens > max_token_budget:
        warnings.append(
            f"Document is very large (~{estimated_tokens:,} estimated tokens, {total_pages} pages). "
            f"Comparison may take longer or require targeted chunking."
        )

    result_meta = DocumentMetadata(
        filename=filename,
        file_size_bytes=file_size,
        file_size_formatted=file_size_str,
        total_pages=total_pages,
        readable_pages_count=readable_pages,
        unreadable_pages_count=unreadable_pages,
        total_characters=total_chars,
        total_words=total_words,
        estimated_tokens=estimated_tokens,
        content_hash=content_hash,
        pages=extracted_pages,
        combined_text=combined_text,
        is_valid=True,
        is_scanned_or_image_only=False,
        error_message=None,
        warnings=warnings,
    )
    _EXTRACTION_CACHE[cache_key] = result_meta
    return result_meta
