"""
test_suite.py
-------------
Automated Verification & Test Suite for AI Document Comparison Assistant.
Verifies all functional requirements and test cases specified in Section 12 of the project brief:
1. Two valid text-based PDFs -> extraction, metrics, and comparisons.
2. One file missing -> validation flags missing file.
3. Wrong file type -> rejection with clear message.
4. Scanned/image-only PDF -> explains no readable text was found; OCR disclaimer.
5. Empty / 0-byte PDF -> rejection without crashing.
6. Password-protected / encrypted PDF -> detects encryption and provides guidance.
7. Documents with different dates/numbers -> accurate identification of delta.
8. Documents with mostly identical content -> no invented differences.
9. Long document / context limit checking -> warning / budget check.
10. Downloadable DOCX report -> generation, sections, and validity.
"""

import io
import os
import unittest
import pypdf

from document_reader import (
    extract_and_validate_pdf,
    DocumentMetadata,
    format_file_size,
)
from comparison import (
    ComparisonResult,
    DocumentSummary,
    SimilarityItem,
    DifferenceItem,
    KeyDetailItem,
    get_sample_policy_comparison,
    clean_and_parse_json,
    build_comparison_prompt,
)
from report_generator import generate_docx_report


class TestDocumentComparisonAssistant(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sample_a = os.path.join("sample_documents", "document_a.pdf")
        cls.sample_b = os.path.join("sample_documents", "document_b.pdf")
        cls.scanned_pdf = os.path.join("sample_documents", "edge_cases", "scanned_image_only.pdf")
        cls.encrypted_pdf = os.path.join("sample_documents", "edge_cases", "encrypted_sample.pdf")
        cls.empty_file = os.path.join("sample_documents", "edge_cases", "empty_file.pdf")

    # Test Case 1: Two valid text-based PDFs
    def test_valid_text_pdfs_extraction(self):
        meta_a = extract_and_validate_pdf(self.sample_a, "document_a.pdf")
        self.assertTrue(meta_a.is_valid)
        self.assertEqual(meta_a.total_pages, 2)
        self.assertGreater(meta_a.total_characters, 1500)
        self.assertIn("GlobalTech", meta_a.combined_text)
        self.assertIn("Dell Latitude", meta_a.combined_text)

        meta_b = extract_and_validate_pdf(self.sample_b, "document_b.pdf")
        self.assertTrue(meta_b.is_valid)
        self.assertEqual(meta_b.total_pages, 2)
        self.assertGreater(meta_b.total_characters, 1500)
        self.assertIn("Cloudflare Zero Trust", meta_b.combined_text)
        self.assertIn("MacBook Pro", meta_b.combined_text)

    # Test Case 2: One file missing
    def test_missing_file_handling(self):
        meta_missing = extract_and_validate_pdf("non_existent_file.pdf", "non_existent_file.pdf")
        self.assertFalse(meta_missing.is_valid)
        self.assertIn("File not found", meta_missing.error_message)

    # Test Case 3: Wrong file type
    def test_wrong_file_type_rejection(self):
        fake_pdf_bytes = b"This is a plain text file pretending to be a PDF"
        meta = extract_and_validate_pdf(fake_pdf_bytes, "fake_doc.pdf")
        self.assertFalse(meta.is_valid)
        self.assertIn("Invalid file format", meta.error_message)

    # Test Case 4: Scanned/image-only PDF detection
    def test_scanned_image_only_pdf(self):
        meta_scan = extract_and_validate_pdf(self.scanned_pdf, "scanned_image_only.pdf")
        self.assertFalse(meta_scan.is_valid)
        self.assertTrue(meta_scan.is_scanned_or_image_only)
        self.assertIn("Optical Character Recognition (OCR) is not performed", meta_scan.error_message)
        self.assertIn("scanned document or image-only", meta_scan.error_message)

    # Test Case 5: Empty / 0-byte PDF
    def test_empty_file_rejection(self):
        meta_empty = extract_and_validate_pdf(self.empty_file, "empty_file.pdf")
        self.assertFalse(meta_empty.is_valid)
        self.assertIn("empty (0 bytes)", meta_empty.error_message)

    # Test Case 6: Password-protected PDF
    def test_encrypted_pdf_detection(self):
        meta_enc = extract_and_validate_pdf(self.encrypted_pdf, "encrypted_sample.pdf")
        self.assertFalse(meta_enc.is_valid)
        self.assertTrue(meta_enc.is_encrypted)
        self.assertIn("password-protected", meta_enc.error_message)

        # Unlock with valid password
        meta_unlocked = extract_and_validate_pdf(self.encrypted_pdf, "encrypted_sample.pdf", password="secret123")
        self.assertTrue(meta_unlocked.is_valid)
        self.assertIn("Confidential Document", meta_unlocked.combined_text)

    # Test Case 7: Key details and numerical comparison accuracy
    def test_numerical_and_date_differences(self):
        comp = get_sample_policy_comparison()
        # Verify stipend difference captured
        stipend_item = next((k for k in comp.key_details if "Stipend" in k.detail), None)
        self.assertIsNotNone(stipend_item)
        self.assertIn("500", stipend_item.document_a)
        self.assertIn("1,000", stipend_item.document_b)

        # Verify date difference captured
        date_item = next((k for k in comp.key_details if "Effective Date" in k.detail), None)
        self.assertIsNotNone(date_item)
        self.assertIn("2024", date_item.document_a)
        self.assertIn("2025", date_item.document_b)

        # Verify notice period difference
        notice_item = next((k for k in comp.key_details if "Notice Period" in k.detail), None)
        self.assertIsNotNone(notice_item)
        self.assertIn("14", notice_item.document_a)
        self.assertIn("30", notice_item.document_b)

    # Test Case 8: Documents with mostly identical content (no invented differences)
    def test_identical_documents_logic(self):
        meta_a1 = extract_and_validate_pdf(self.sample_a, "document_a_copy1.pdf")
        meta_a2 = extract_and_validate_pdf(self.sample_a, "document_a_copy2.pdf")
        self.assertEqual(meta_a1.combined_text, meta_a2.combined_text)
        prompt = build_comparison_prompt("doc_a1.pdf", meta_a1.combined_text, "doc_a2.pdf", meta_a2.combined_text)
        from comparison import SYSTEM_INSTRUCTION
        self.assertIn("STRICT OPERATIONAL RULES", SYSTEM_INSTRUCTION)
        self.assertIn("Never invent dates, monetary figures", SYSTEM_INSTRUCTION)

    # Test Case 9: Context limit budget check
    def test_token_budget_warning(self):
        meta = extract_and_validate_pdf(self.sample_a, "document_a.pdf", max_token_budget=100)
        # Should add a warning that document exceeds budget
        self.assertTrue(any("very large" in w for w in meta.warnings))

    # Test Case 10: Downloadable DOCX report generation
    def test_docx_report_generation(self):
        comp = get_sample_policy_comparison()
        meta_a = extract_and_validate_pdf(self.sample_a, "document_a.pdf")
        meta_b = extract_and_validate_pdf(self.sample_b, "document_b.pdf")
        buf = generate_docx_report(comp, meta_a, meta_b)
        self.assertIsInstance(buf, io.BytesIO)
        raw_bytes = buf.getvalue()
        self.assertGreater(len(raw_bytes), 20000)
        # Check docx zip signature (PK)
        self.assertTrue(raw_bytes.startswith(b"PK"))

    # Test Case 11: JSON Cleaner / Parser resilience
    def test_json_cleaner_resilience(self):
        markdown_wrapped = """```json
        {
            "detail": "Test Detail",
            "val": 123,
        }
        ```"""
        parsed = clean_and_parse_json(markdown_wrapped)
        self.assertEqual(parsed["detail"], "Test Detail")
        self.assertEqual(parsed["val"], 123)


if __name__ == "__main__":
    unittest.main()
