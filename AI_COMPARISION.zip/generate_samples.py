"""
generate_samples.py
-------------------
Utility script to generate realistic sample PDF documents for testing the
AI Document Comparison Assistant, including edge-case files:
1. document_a.pdf: Remote Work & Equipment Policy v1.2 (2024)
2. document_b.pdf: Remote Work & Equipment Policy v2.0 (2025)
3. edge_cases/scanned_image_only.pdf: Image-only document with 0 extractable text
4. edge_cases/encrypted_sample.pdf: Password-protected PDF
5. edge_cases/empty_file.pdf: 0-byte file
"""

import os
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.pdfgen import canvas
import pypdf


def create_document_a(filepath: str):
    """Generates Document A: Remote Work & Equipment Policy v1.2 (2024)."""
    doc = SimpleDocTemplate(filepath, pagesize=letter, leftMargin=54, rightMargin=54, topMargin=54, bottomMargin=54)
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=20,
        leading=24,
        textColor=colors.HexColor('#1E3A8A'),
        spaceAfter=12
    )
    h2_style = ParagraphStyle(
        'DocH2',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=13,
        leading=16,
        textColor=colors.HexColor('#1E40AF'),
        spaceBefore=10,
        spaceAfter=6
    )
    body_style = ParagraphStyle(
        'DocBody',
        parent=styles['BodyText'],
        fontName='Helvetica',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#1F2937'),
        spaceAfter=6
    )
    bullet_style = ParagraphStyle(
        'DocBullet',
        parent=body_style,
        leftIndent=15,
        firstLineIndent=-10,
        spaceAfter=4
    )

    story = []

    # Header / Title
    story.append(Paragraph("GlobalTech Solutions — Remote Work & Equipment Policy", title_style))
    story.append(Paragraph("<b>Document Version:</b> 1.2 | <b>Status:</b> Approved | <b>Effective Date:</b> January 15, 2024", body_style))
    story.append(Paragraph("<b>Issuing Authority:</b> People Operations & IT Infrastructure Committee", body_style))
    story.append(Spacer(1, 10))

    # Section 1: Purpose & Scope
    story.append(Paragraph("1. Purpose and Scope", h2_style))
    story.append(Paragraph(
        "This policy defines the terms, responsibilities, and guidelines under which employees of GlobalTech Solutions "
        "may perform remote work. This policy applies to all full-time regular employees based in North America. "
        "Contractors, interns, and part-time staff are excluded from remote work eligibility under Version 1.2.",
        body_style
    ))

    # Section 2: Eligibility & Working Hours
    story.append(Paragraph("2. Eligibility Criteria & Schedule", h2_style))
    story.append(Paragraph("• <b>Tenure Requirement:</b> Employees must complete at least 6 months of continuous service before requesting remote work.", bullet_style))
    story.append(Paragraph("• <b>Eligible Remote Days:</b> Maximum of 2 remote working days per week (Tuesdays and Thursdays are designated core in-office days).", bullet_style))
    story.append(Paragraph("• <b>Standard Working Hours:</b> 9:00 AM to 5:00 PM EST. All remote staff must be logged into Slack during core working hours.", bullet_style))
    story.append(Paragraph("• <b>Mandatory Team Sync:</b> Every Monday at 10:00 AM EST via Zoom.", bullet_style))

    # Section 3: Equipment & Stipend
    story.append(Paragraph("3. Equipment & Home Office Stipend", h2_style))
    story.append(Paragraph(
        "GlobalTech provides the following allowances and equipment to approved remote employees:",
        body_style
    ))
    story.append(Paragraph("• <b>Hardware Provided:</b> One standard 14-inch Dell Latitude 5430 laptop, one mouse, and one USB-C docking station.", bullet_style))
    story.append(Paragraph("• <b>Initial Setup Stipend:</b> A one-time lump-sum stipend of $500 USD for ergonomic home office furniture, reimbursable within 60 days of approval.", bullet_style))
    story.append(Paragraph("• <b>Monthly Internet Subsidy:</b> $50 USD per month processed through standard payroll.", bullet_style))
    story.append(Paragraph("• <b>Hardware Refresh Cycle:</b> Company hardware is replaced every 48 months (4 years).", bullet_style))

    story.append(PageBreak())  # Page 2

    # Section 4: Information Security & Data Protection
    story.append(Paragraph("4. Information Security & Compliance", h2_style))
    story.append(Paragraph(
        "Remote staff must adhere strictly to GlobalTech's Information Security Guidelines. Failure to comply will result in "
        "immediate revocation of remote privileges.",
        body_style
    ))
    story.append(Paragraph("• <b>VPN Usage:</b> Mandatory connection to GlobalTech Corporate VPN (OpenVPN Client) whenever accessing company servers.", bullet_style))
    story.append(Paragraph("• <b>Authentication:</b> Multi-Factor Authentication (MFA) via SMS OTP or Google Authenticator.", bullet_style))
    story.append(Paragraph("• <b>Public Wi-Fi:</b> Strictly prohibited from working on unsecured public Wi-Fi networks without an active VPN tunnel.", bullet_style))
    story.append(Paragraph("• <b>Device Sharing:</b> Family members and third parties are strictly prohibited from using company-issued devices.", bullet_style))

    # Section 5: Reimbursement & Expense Submission
    story.append(Paragraph("5. Expense Claims and Deadlines", h2_style))
    story.append(Paragraph(
        "All home office and broadband reimbursement receipts must be submitted through Expensify no later than the "
        "25th day of each calendar month. Claims submitted after the 25th will be rolled over to the following payroll cycle.",
        body_style
    ))

    # Section 6: Termination of Remote Privileges
    story.append(Paragraph("6. Revocation and Termination Notice", h2_style))
    story.append(Paragraph(
        "Management reserves the right to terminate remote working arrangements at any time. A standard written notice "
        "period of 14 calendar days will be provided to the employee prior to revoking remote privileges, except in cases of "
        "gross misconduct or data security breaches where termination is immediate.",
        body_style
    ))

    # Section 7: Policy Contacts
    story.append(Paragraph("7. Policy Administration & Contacts", h2_style))
    story.append(Paragraph(
        "For questions regarding this policy, contact People Operations at <b>hr-support@globaltech-solutions.internal</b> "
        "or IT Helpdesk at extension 4022.",
        body_style
    ))

    doc.build(story)
    print(f"Created: {filepath}")


def create_document_b(filepath: str):
    """Generates Document B: Remote Work & Equipment Policy v2.0 (2025)."""
    doc = SimpleDocTemplate(filepath, pagesize=letter, leftMargin=54, rightMargin=54, topMargin=54, bottomMargin=54)
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=20,
        leading=24,
        textColor=colors.HexColor('#065F46'),
        spaceAfter=12
    )
    h2_style = ParagraphStyle(
        'DocH2',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=13,
        leading=16,
        textColor=colors.HexColor('#047857'),
        spaceBefore=10,
        spaceAfter=6
    )
    body_style = ParagraphStyle(
        'DocBody',
        parent=styles['BodyText'],
        fontName='Helvetica',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#1F2937'),
        spaceAfter=6
    )
    bullet_style = ParagraphStyle(
        'DocBullet',
        parent=body_style,
        leftIndent=15,
        firstLineIndent=-10,
        spaceAfter=4
    )

    story = []

    # Header / Title
    story.append(Paragraph("GlobalTech Solutions — Remote Work & Equipment Policy", title_style))
    story.append(Paragraph("<b>Document Version:</b> 2.0 | <b>Status:</b> Approved | <b>Effective Date:</b> February 01, 2025", body_style))
    story.append(Paragraph("<b>Issuing Authority:</b> Global Workplace Experience & Cybersecurity Council", body_style))
    story.append(Spacer(1, 10))

    # Section 1: Purpose & Scope
    story.append(Paragraph("1. Purpose and Scope", h2_style))
    story.append(Paragraph(
        "This policy establishes the updated framework, eligibility criteria, and operational standards for remote and hybrid "
        "employment at GlobalTech Solutions. Version 2.0 applies globally to all full-time regular employees, full-time contractors, "
        "and graduate engineering interns with manager sign-off.",
        body_style
    ))

    # Section 2: Eligibility & Working Hours
    story.append(Paragraph("2. Eligibility Criteria & Schedule", h2_style))
    story.append(Paragraph("• <b>Tenure Requirement:</b> Employees are eligible immediately upon successful completion of the 90-day probationary period.", bullet_style))
    story.append(Paragraph("• <b>Eligible Remote Days:</b> Increased to up to 4 remote working days per week (Only Wednesdays are mandatory in-office collaboration days).", bullet_style))
    story.append(Paragraph("• <b>Flexible Working Hours:</b> Core hours are 10:00 AM to 3:00 PM EST, with flexible 8-hour shift bands spanning between 7:00 AM and 7:00 PM EST.", bullet_style))
    story.append(Paragraph("• <b>Mandatory Team Sync:</b> Rescheduled to Tuesdays at 11:00 AM EST via Google Meet.", bullet_style))

    # Section 3: Equipment & Stipend
    story.append(Paragraph("3. Equipment & Home Office Stipend", h2_style))
    story.append(Paragraph(
        "GlobalTech provides upgraded allowances and equipment to approved remote employees:",
        body_style
    ))
    story.append(Paragraph("• <b>Hardware Provided:</b> Choice of 16-inch Apple MacBook Pro (M3) or 15-inch ThinkPad P1 Gen 6, dual 27-inch 4K monitors, and ergonomic keyboard/mouse.", bullet_style))
    story.append(Paragraph("• <b>Initial Setup Stipend:</b> Increased to $1,000 USD (or local currency equivalent), reimbursable within 90 days of onboarding.", bullet_style))
    story.append(Paragraph("• <b>Monthly Internet & Utility Subsidy:</b> Increased to $85 USD per month.", bullet_style))
    story.append(Paragraph("• <b>Hardware Refresh Cycle:</b> Shortened to every 36 months (3 years) to keep pace with engineering requirements.", bullet_style))
    story.append(Paragraph("• <b>Annual Ergonomic Refresh:</b> NEW: Additional annual health & ergonomic stipend of $250 USD per calendar year.", bullet_style))

    story.append(PageBreak())  # Page 2

    # Section 4: Information Security & Data Protection
    story.append(Paragraph("4. Information Security & Compliance", h2_style))
    story.append(Paragraph(
        "GlobalTech adheres to strict Zero-Trust cybersecurity standards. All remote devices and data transmissions are governed "
        "by the Global Security Operations Center (SOC).",
        body_style
    ))
    story.append(Paragraph("• <b>Zero-Trust Network Access (ZTNA):</b> Cloudflare Zero Trust replaces legacy OpenVPN. Endpoint must run SentinelOne EDR.", bullet_style))
    story.append(Paragraph("• <b>Authentication:</b> FIDO2 Hardware Security Keys (YubiKey) or Okta Verify with biometric push. SMS OTP is deprecated and prohibited.", bullet_style))
    story.append(Paragraph("• <b>Public Wi-Fi:</b> Permitted only when Cloudflare WARP client is active and verified.", bullet_style))
    story.append(Paragraph("• <b>Device Sharing:</b> Strictly prohibited. Any unauthorized access constitutes immediate termination of employment.", bullet_style))

    # Section 5: Reimbursement & Expense Submission
    story.append(Paragraph("5. Expense Claims and Deadlines", h2_style))
    story.append(Paragraph(
        "Expense receipts must be submitted via the new Ramp enterprise portal no later than the 20th day of each calendar month. "
        "Late submissions will be delayed by one billing cycle.",
        body_style
    ))

    # Section 6: Termination of Remote Privileges
    story.append(Paragraph("6. Revocation and Termination Notice", h2_style))
    story.append(Paragraph(
        "Should business needs or performance metrics require an employee to return full-time to the office, GlobalTech will "
        "provide a minimum written notice period of 30 calendar days (increased from 14 days) to allow adequate commuting adjustments.",
        body_style
    ))

    # Section 7: Policy Contacts & Support
    story.append(Paragraph("7. Policy Administration & Contacts", h2_style))
    story.append(Paragraph(
        "For policy clarifications, contact Workplace Experience at <b>workplace@globaltech-solutions.internal</b> "
        "or log a ticket via Jira Service Desk at <b>go/helpdesk</b>.",
        body_style
    ))

    doc.build(story)
    print(f"Created: {filepath}")


def create_scanned_image_only_pdf(filepath: str):
    """Creates a PDF with zero extractable text (simulates a scanned image)."""
    c = canvas.Canvas(filepath, pagesize=letter)
    # Draw shapes and lines, but no text strings
    c.setFillColor(colors.HexColor('#E5E7EB'))
    c.rect(50, 50, 500, 650, fill=1, stroke=1)
    c.setFillColor(colors.HexColor('#9CA3AF'))
    # Draw simulated photo / graphic rectangles
    c.rect(80, 500, 440, 150, fill=1, stroke=0)
    c.rect(80, 300, 440, 150, fill=1, stroke=0)
    c.rect(80, 100, 440, 150, fill=1, stroke=0)
    c.showPage()
    c.save()
    print(f"Created scanned sample: {filepath}")


def create_encrypted_pdf(filepath: str, password: str = "secret123"):
    """Creates a password-protected PDF to test encryption handling."""
    temp_path = filepath + ".tmp.pdf"
    c = canvas.Canvas(temp_path, pagesize=letter)
    c.drawString(100, 700, "Confidential Document — Requires Authentication")
    c.drawString(100, 680, "This is encrypted test content for verification.")
    c.showPage()
    c.save()

    # Encrypt using pypdf
    reader = pypdf.PdfReader(temp_path)
    writer = pypdf.PdfWriter()
    for page in reader.pages:
        writer.add_page(page)
    writer.encrypt(password)
    with open(filepath, "wb") as f:
        writer.write(f)
    if os.path.exists(temp_path):
        os.remove(temp_path)
    print(f"Created encrypted sample: {filepath} (password: {password})")


def create_empty_file(filepath: str):
    """Creates a 0-byte file to test empty upload validation."""
    with open(filepath, "wb") as f:
        pass
    print(f"Created empty sample: {filepath}")


def main():
    base_dir = r"c:\AI_DOCUMENT_COMPARISION"
    samples_dir = os.path.join(base_dir, "sample_documents")
    edge_dir = os.path.join(samples_dir, "edge_cases")
    os.makedirs(samples_dir, exist_ok=True)
    os.makedirs(edge_dir, exist_ok=True)

    create_document_a(os.path.join(samples_dir, "document_a.pdf"))
    create_document_b(os.path.join(samples_dir, "document_b.pdf"))
    create_scanned_image_only_pdf(os.path.join(edge_dir, "scanned_image_only.pdf"))
    create_encrypted_pdf(os.path.join(edge_dir, "encrypted_sample.pdf"), "secret123")
    create_empty_file(os.path.join(edge_dir, "empty_file.pdf"))
    print("All sample and edge-case PDF documents generated successfully!")


if __name__ == "__main__":
    main()
