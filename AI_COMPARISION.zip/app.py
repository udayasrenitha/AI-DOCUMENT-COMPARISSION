"""
app.py
------
AI Document Comparison Assistant
World-class, executive-tier web application for deep comparative analysis of PDF documents.

Features:
- Cutting-edge modern glassmorphism UI with curated dark theme & Google Fonts.
- Complete end-to-end functionality with live Google Gemini 3.5 API reasoning.
- Interactive inline decryption for password-protected/encrypted PDFs.
- Scanned/image-only document detection without false OCR claims.
- Page-by-page extracted text inspector and token budget metrics.
- 7 comprehensive results tabs: Summaries, Similarities, Differences, Key Details, Conclusion, Limitations.
- Search and category filters for change items.
- Dual export options: Microsoft Word (.docx) executive report and JSON structured data.
- Built-in sample loaders & Instant Offline Benchmark Demo.
"""

import hashlib
import json
import os
import time
from typing import Optional
import pandas as pd
import streamlit as st
from dotenv import load_dotenv

# Load backend environment variables
load_dotenv()

from document_reader import (
    DocumentMetadata,
    extract_and_validate_pdf,
)
from comparison import (
    ComparisonResult,
    compare_documents_with_gemini,
    get_sample_policy_comparison,
)
from report_generator import generate_docx_report


# ==============================================================================
# Page Configuration & Executive Glassmorphic Styling
# ==============================================================================

st.set_page_config(
    page_title="AI Document Comparison Assistant",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="collapsed",
)

CUSTOM_CSS = """
<style>
    /* Import Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');

    /* Hide default Streamlit sidebar and decoration */
    [data-testid="stSidebar"] { display: none !important; }
    [data-testid="collapsedControl"] { display: none !important; }
    #MainMenu { visibility: hidden; }
    footer { visibility: hidden; }
    header { visibility: hidden; }

    /* Root theme colors & base canvas */
    :root {
        --bg-main: #0B0F19;
        --card-bg: rgba(17, 24, 39, 0.78);
        --card-border: rgba(255, 255, 255, 0.08);
        --text-primary: #F8FAFC;
        --text-secondary: #94A3B8;
        --text-muted: #64748B;
        --accent-indigo: #6366F1;
        --accent-violet: #8B5CF6;
        --accent-emerald: #10B981;
        --accent-amber: #F59E0B;
        --accent-rose: #F43F5E;
    }

    .stApp {
        background-color: var(--bg-main);
        background-image: 
            radial-gradient(circle at 50% 0%, rgba(99, 102, 241, 0.12) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(139, 92, 246, 0.08) 0%, transparent 40%),
            radial-gradient(circle at 20% 80%, rgba(16, 185, 129, 0.05) 0%, transparent 40%);
        color: var(--text-primary);
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
    }

    /* Headings & Text */
    h1, h2, h3, h4, h5, h6 {
        font-family: 'Plus Jakarta Sans', sans-serif;
        color: #F8FAFC !important;
        font-weight: 700;
        letter-spacing: -0.02em;
    }

    p, span, label, div {
        color: #E2E8F0;
    }

    /* Hero Header Banner */
    .hero-container {
        text-align: center;
        padding: 2.2rem 1rem 1.2rem 1rem;
        position: relative;
    }
    .hero-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        background: rgba(99, 102, 241, 0.15);
        border: 1px solid rgba(99, 102, 241, 0.35);
        border-radius: 9999px;
        padding: 0.35rem 0.9rem;
        font-size: 0.82rem;
        font-weight: 600;
        color: #A5B4FC;
        margin-bottom: 1rem;
        backdrop-filter: blur(8px);
    }
    .hero-badge .pulse-dot {
        width: 8px;
        height: 8px;
        background-color: #10B981;
        border-radius: 50%;
        box-shadow: 0 0 10px #10B981;
    }
    .hero-title {
        font-size: 2.75rem;
        font-weight: 800;
        background: linear-gradient(135deg, #FFFFFF 0%, #E2E8F0 40%, #A5B4FC 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.6rem;
        letter-spacing: -0.03em;
        line-height: 1.15;
    }
    .hero-subtitle {
        font-size: 1.1rem;
        color: #94A3B8;
        max-width: 780px;
        margin: 0 auto 1.5rem auto;
        line-height: 1.6;
    }

    /* Feature Highlights Chips */
    .feature-strip {
        display: flex;
        justify-content: center;
        gap: 1.5rem;
        margin-bottom: 2rem;
        flex-wrap: wrap;
    }
    .feature-pill {
        display: flex;
        align-items: center;
        gap: 0.4rem;
        font-size: 0.85rem;
        color: #CBD5E1;
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.08);
        padding: 0.35rem 0.85rem;
        border-radius: 8px;
    }

    /* Stepper Workflow Navigation */
    .stepper-bar {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 1rem;
        margin: 0 auto 2.2rem auto;
        flex-wrap: wrap;
    }
    .step-item {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        background: rgba(17, 24, 39, 0.6);
        border: 1px solid rgba(255, 255, 255, 0.08);
        padding: 0.55rem 1.1rem;
        border-radius: 9999px;
        font-size: 0.88rem;
        font-weight: 600;
        color: #64748B;
        transition: all 0.25s ease;
    }
    .step-item.active {
        background: rgba(99, 102, 241, 0.16);
        border-color: rgba(99, 102, 241, 0.4);
        color: #C7D2FE;
        box-shadow: 0 0 15px rgba(99, 102, 241, 0.15);
    }
    .step-item.completed {
        background: rgba(16, 185, 129, 0.12);
        border-color: rgba(16, 185, 129, 0.35);
        color: #6EE7B7;
    }
    .step-num {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 22px;
        height: 22px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.1);
        font-size: 0.75rem;
    }
    .step-item.active .step-num {
        background: #6366F1;
        color: #FFFFFF;
    }
    .step-item.completed .step-num {
        background: #10B981;
        color: #FFFFFF;
    }
    .step-divider {
        color: #334155;
        font-weight: 700;
    }

    /* Glass Cards */
    .glass-card {
        background: var(--card-bg);
        border: 1px solid var(--card-border);
        border-radius: 16px;
        padding: 1.5rem;
        box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(12px);
        margin-bottom: 1.5rem;
        transition: border-color 0.2s ease, transform 0.2s ease;
    }
    .glass-card:hover {
        border-color: rgba(255, 255, 255, 0.15);
    }
    .card-header-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 1rem;
        border-bottom: 1px solid rgba(255, 255, 255, 0.06);
        padding-bottom: 0.75rem;
    }
    .card-title {
        font-size: 1.18rem;
        font-weight: 700;
        color: #F8FAFC;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    /* Metrics Grid */
    .metric-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(110px, 1fr));
        gap: 0.6rem;
        margin: 0.9rem 0;
    }
    .metric-box {
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.06);
        border-radius: 10px;
        padding: 0.6rem 0.75rem;
        text-align: center;
    }
    .metric-val {
        font-size: 1.05rem;
        font-weight: 700;
        color: #F8FAFC;
        font-family: 'JetBrains Mono', monospace;
    }
    .metric-lbl {
        font-size: 0.72rem;
        color: #94A3B8;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-top: 2px;
    }

    /* Difference Badges */
    .badge-diff {
        display: inline-block;
        padding: 3px 10px;
        border-radius: 6px;
        font-size: 0.76rem;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
    }
    .badge-added {
        background: rgba(16, 185, 129, 0.18);
        border: 1px solid rgba(16, 185, 129, 0.4);
        color: #34D399;
    }
    .badge-removed {
        background: rgba(244, 63, 94, 0.18);
        border: 1px solid rgba(244, 63, 94, 0.4);
        color: #FB7185;
    }
    .badge-modified {
        background: rgba(245, 158, 11, 0.18);
        border: 1px solid rgba(245, 158, 11, 0.4);
        color: #FBBF24;
    }
    .badge-conflicting {
        background: rgba(139, 92, 246, 0.18);
        border: 1px solid rgba(139, 92, 246, 0.4);
        color: #C084FC;
    }
    .badge-uncertain {
        background: rgba(148, 163, 184, 0.18);
        border: 1px solid rgba(148, 163, 184, 0.4);
        color: #CBD5E1;
    }

    /* KPI Scorecard */
    .kpi-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
        gap: 0.8rem;
        margin: 1.2rem 0 1.8rem 0;
    }
    .kpi-card {
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 12px;
        padding: 0.9rem;
        text-align: center;
        transition: transform 0.2s ease, border-color 0.2s ease;
    }
    .kpi-card:hover {
        transform: translateY(-2px);
        border-color: rgba(99, 102, 241, 0.4);
    }
    .kpi-number {
        font-size: 1.7rem;
        font-weight: 800;
        font-family: 'JetBrains Mono', monospace;
        line-height: 1.1;
    }
    .kpi-title {
        font-size: 0.76rem;
        color: #94A3B8;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-top: 4px;
    }

    /* Side-by-side Evidence Comparison Boxes */
    .diff-card {
        background: rgba(255, 255, 255, 0.025);
        border: 1px solid rgba(255, 255, 255, 0.07);
        border-radius: 12px;
        padding: 1.1rem;
        margin-bottom: 1rem;
    }
    .evidence-box {
        background: rgba(15, 23, 42, 0.6);
        border: 1px solid rgba(255, 255, 255, 0.06);
        border-radius: 8px;
        padding: 0.75rem;
        margin-top: 0.5rem;
    }
    .evidence-citation {
        font-family: 'JetBrains Mono', monospace;
        font-size: 0.75rem;
        color: #818CF8;
        margin-top: 4px;
    }

    /* Callout & Disclaimer */
    .alert-callout {
        background: rgba(99, 102, 241, 0.08);
        border-left: 4px solid #6366F1;
        padding: 1rem 1.25rem;
        border-radius: 0 10px 10px 0;
        margin: 1.2rem 0;
    }
    .disclaimer-text {
        font-size: 0.82rem;
        color: #64748B;
        text-align: center;
        margin: 2rem 0 1rem 0;
        line-height: 1.5;
    }

    /* Streamlit Custom Element Overrides */
    div.stButton > button {
        border-radius: 10px !important;
        font-weight: 600 !important;
        transition: all 0.2s ease !important;
    }
    div.stButton > button[kind="primary"] {
        background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%) !important;
        border: 1px solid rgba(255, 255, 255, 0.2) !important;
        color: #FFFFFF !important;
        box-shadow: 0 4px 15px rgba(99, 102, 241, 0.35) !important;
    }
    div.stButton > button[kind="primary"]:hover {
        background: linear-gradient(135deg, #4338CA 0%, #6D28D9 100%) !important;
        box-shadow: 0 6px 22px rgba(99, 102, 241, 0.55) !important;
        transform: translateY(-1px);
    }
    div.stButton > button[kind="secondary"] {
        background: rgba(255, 255, 255, 0.05) !important;
        border: 1px solid rgba(255, 255, 255, 0.12) !important;
        color: #E2E8F0 !important;
    }
    div.stButton > button[kind="secondary"]:hover {
        background: rgba(255, 255, 255, 0.1) !important;
        border-color: rgba(255, 255, 255, 0.25) !important;
    }

    /* Streamlit Tabs Styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background-color: rgba(15, 23, 42, 0.7);
        padding: 6px;
        border-radius: 12px;
        border: 1px solid rgba(255, 255, 255, 0.08);
    }
    .stTabs [data-baseweb="tab"] {
        border-radius: 8px;
        color: #94A3B8 !important;
        font-weight: 600;
        padding: 8px 16px;
        border: none !important;
    }
    .stTabs [aria-selected="true"] {
        background-color: rgba(99, 102, 241, 0.25) !important;
        color: #FFFFFF !important;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
    }

    /* Dataframe dark table styling */
    [data-testid="stDataFrame"] {
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 12px;
        overflow: hidden;
    }

    /* Expander styling */
    .streamlit-expanderHeader {
        background: rgba(255, 255, 255, 0.02) !important;
        border-radius: 8px !important;
        font-weight: 600 !important;
    }
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


# ==============================================================================
# Session State Initialization & Caching Architecture
# ==============================================================================

if "uploader_key" not in st.session_state:
    st.session_state.uploader_key = 0
if "doc_a_meta" not in st.session_state:
    st.session_state.doc_a_meta = None
if "doc_b_meta" not in st.session_state:
    st.session_state.doc_b_meta = None
if "file_a_bytes" not in st.session_state:
    st.session_state.file_a_bytes = None
if "file_b_bytes" not in st.session_state:
    st.session_state.file_b_bytes = None
if "file_a_name" not in st.session_state:
    st.session_state.file_a_name = ""
if "file_b_name" not in st.session_state:
    st.session_state.file_b_name = ""
if "file_a_hash" not in st.session_state:
    st.session_state.file_a_hash = None
if "file_b_hash" not in st.session_state:
    st.session_state.file_b_hash = None
if "comparison_result" not in st.session_state:
    st.session_state.comparison_result = None
if "comparison_error" not in st.session_state:
    st.session_state.comparison_error = None
if "comparison_cache" not in st.session_state:
    st.session_state.comparison_cache = {}
if "cached_report_bytes" not in st.session_state:
    st.session_state.cached_report_bytes = None
if "cached_report_key" not in st.session_state:
    st.session_state.cached_report_key = None
if "is_processing" not in st.session_state:
    st.session_state.is_processing = False
if "selected_model" not in st.session_state:
    st.session_state.selected_model = os.getenv("GEMINI_MODEL", "gemini-3.5-flash")


def reset_comparison():
    """Resets all uploaded files, extractions, and comparison results."""
    st.session_state.uploader_key += 1
    st.session_state.doc_a_meta = None
    st.session_state.doc_b_meta = None
    st.session_state.file_a_bytes = None
    st.session_state.file_b_bytes = None
    st.session_state.file_a_name = ""
    st.session_state.file_b_name = ""
    st.session_state.file_a_hash = None
    st.session_state.file_b_hash = None
    st.session_state.comparison_result = None
    st.session_state.comparison_error = None
    st.session_state.cached_report_bytes = None
    st.session_state.cached_report_key = None
    st.session_state.is_processing = False


# ==============================================================================
# Header & Navigation Banner
# ==============================================================================

backend_api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
active_model = st.session_state.selected_model

st.markdown(
    f"""
    <div class="hero-container">
        <div class="hero-badge">
            <span class="pulse-dot"></span>
            <span>Gemini AI Engine Active &bull; {active_model}</span>
        </div>
        <div class="hero-title">AI Document Comparison Assistant</div>
        <div class="hero-subtitle">
            Enterprise-grade document comparison engine powered by Google Gemini. Upload any two versions
            of a policy, contract, syllabus, or technical specification to discover similarities,
            categorized differences, and verifiable key numerical changes with 100% page citation traceability.
        </div>
        <div class="feature-strip">
            <div class="feature-pill">🛡️ Strict Anti-Hallucination</div>
            <div class="feature-pill">📍 Page-Level Evidence Citations</div>
            <div class="feature-pill">🔒 Encrypted PDF Support</div>
            <div class="feature-pill">📄 Instant Word (.docx) Export</div>
            <div class="feature-pill">⚡ Fast Hash Caching</div>
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)

# Workflow Stepper State Computation
meta_a: Optional[DocumentMetadata] = st.session_state.doc_a_meta
meta_b: Optional[DocumentMetadata] = st.session_state.doc_b_meta
comp: Optional[ComparisonResult] = st.session_state.comparison_result

step1_cls = "completed" if (meta_a and meta_b and meta_a.is_valid and meta_b.is_valid) else "active"
step2_cls = "completed" if comp else ("active" if step1_cls == "completed" else "")
step3_cls = "active" if comp else ""

st.markdown(
    f"""
    <div class="stepper-bar">
        <div class="step-item {step1_cls}">
            <span class="step-num">1</span>
            <span>Upload & Validate</span>
        </div>
        <div class="step-divider">➔</div>
        <div class="step-item {step2_cls}">
            <span class="step-num">2</span>
            <span>AI Comparative Reasoning</span>
        </div>
        <div class="step-divider">➔</div>
        <div class="step-item {step3_cls}">
            <span class="step-num">3</span>
            <span>Executive Review & Export</span>
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)


# ==============================================================================
# Quick Loaders & Environment Health Bar
# ==============================================================================

sample_a_path = os.path.join("sample_documents", "document_a.pdf")
sample_b_path = os.path.join("sample_documents", "document_b.pdf")
sample_enc_path = os.path.join("sample_documents", "edge_cases", "encrypted_sample.pdf")
sample_scan_path = os.path.join("sample_documents", "edge_cases", "scanned_image_only.pdf")

with st.container():
    c_btn1, c_btn2, c_btn3, c_btn4, c_btn5 = st.columns([1.6, 1.2, 1.2, 1.3, 0.9])

    with c_btn1:
        if st.button("📁 Load Policy Samples (v1.2 & v2.0)", use_container_width=True, help="Load Remote Work Policy v1.2 vs v2.0 benchmark files"):
            if os.path.exists(sample_a_path) and os.path.exists(sample_b_path):
                st.session_state.doc_a_meta = extract_and_validate_pdf(sample_a_path, "document_a.pdf (Policy v1.2)")
                st.session_state.doc_b_meta = extract_and_validate_pdf(sample_b_path, "document_b.pdf (Policy v2.0)")
                with open(sample_a_path, "rb") as f:
                    st.session_state.file_a_bytes = f.read()
                with open(sample_b_path, "rb") as f:
                    st.session_state.file_b_bytes = f.read()
                st.session_state.file_a_name = "document_a.pdf"
                st.session_state.file_b_name = "document_b.pdf"
                st.session_state.file_a_hash = st.session_state.doc_a_meta.content_hash
                st.session_state.file_b_hash = st.session_state.doc_b_meta.content_hash
                st.session_state.comparison_result = None
                st.rerun()

    with c_btn2:
        if st.button("🔒 Test Encrypted PDF", use_container_width=True, help="Load password-protected PDF to test inline decryption"):
            if os.path.exists(sample_enc_path) and os.path.exists(sample_b_path):
                with open(sample_enc_path, "rb") as f:
                    st.session_state.file_a_bytes = f.read()
                st.session_state.file_a_name = "encrypted_sample.pdf"
                st.session_state.doc_a_meta = extract_and_validate_pdf(st.session_state.file_a_bytes, "encrypted_sample.pdf")
                st.session_state.doc_b_meta = extract_and_validate_pdf(sample_b_path, "document_b.pdf (Policy v2.0)")
                st.session_state.comparison_result = None
                st.rerun()

    with c_btn3:
        if st.button("🖼️ Test Scanned PDF", use_container_width=True, help="Load image-only PDF to test OCR limitation handling"):
            if os.path.exists(sample_scan_path) and os.path.exists(sample_b_path):
                st.session_state.doc_a_meta = extract_and_validate_pdf(sample_scan_path, "scanned_image_only.pdf")
                st.session_state.doc_b_meta = extract_and_validate_pdf(sample_b_path, "document_b.pdf (Policy v2.0)")
                st.session_state.comparison_result = None
                st.rerun()

    with c_btn4:
        if st.button("⚡ Offline Demo Mode", use_container_width=True, help="Instantly load pre-computed comparison result without calling Gemini API"):
            if os.path.exists(sample_a_path) and os.path.exists(sample_b_path):
                st.session_state.doc_a_meta = extract_and_validate_pdf(sample_a_path, "document_a.pdf (Policy v1.2)")
                st.session_state.doc_b_meta = extract_and_validate_pdf(sample_b_path, "document_b.pdf (Policy v2.0)")
                st.session_state.comparison_result = get_sample_policy_comparison()
                st.session_state.comparison_error = None
                st.rerun()

    with c_btn5:
        if st.button("🔄 Reset", use_container_width=True, help="Clear all documents and results"):
            reset_comparison()
            st.rerun()

st.write("")

# Backend API Status Warning (if missing)
if not backend_api_key:
    st.warning(
        "⚠️ **Gemini API Key is not set in `.env`.** The application will allow file inspection and Offline Demo Mode. "
        "To perform live comparisons with Gemini AI, configure `GEMINI_API_KEY` in your `.env` file.",
        icon="🔑",
    )


# ==============================================================================
# Document Upload & Interactive Inspection Panels (Side-by-Side Cards)
# ==============================================================================

col_left, col_right = st.columns(2, gap="large")

# ------------------------------------------------------------------------------
# PANEL A: Document A (Original / Baseline)
# ------------------------------------------------------------------------------
with col_left:
    st.markdown(
        """
        <div class="card-header-row">
            <div class="card-title">📄 Document A &mdash; Original Document</div>
            <span style="font-size: 0.8rem; color: #94A3B8;">Baseline Version</span>
        </div>
        """,
        unsafe_allow_html=True,
    )

    uploaded_file_a = st.file_uploader(
        "Choose original PDF",
        type=["pdf"],
        key=f"file_a_uploader_{st.session_state.uploader_key}",
        help="Upload the earlier version or baseline document (PDF).",
        label_visibility="collapsed",
    )

    if uploaded_file_a is not None:
        file_a_bytes = uploaded_file_a.getvalue()
        current_hash_a = hashlib.sha256(file_a_bytes).hexdigest()
        if st.session_state.file_a_hash != current_hash_a or st.session_state.doc_a_meta is None:
            st.session_state.file_a_bytes = file_a_bytes
            st.session_state.file_a_name = uploaded_file_a.name
            st.session_state.doc_a_meta = extract_and_validate_pdf(file_a_bytes, filename=uploaded_file_a.name)
            st.session_state.file_a_hash = current_hash_a
            st.session_state.comparison_result = None
            st.session_state.cached_report_bytes = None

    meta_a = st.session_state.doc_a_meta

    if meta_a:
        # Check if file is encrypted and needs password unlock
        if meta_a.is_encrypted and not meta_a.is_valid:
            st.error(f"🔒 **Password-Protected PDF:** {meta_a.error_message}")
            with st.container():
                st.markdown("<div style='background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); border-radius: 10px; padding: 1rem;'>", unsafe_allow_html=True)
                st.markdown("##### 🔓 Unlock Document A")
                pwd_col1, pwd_col2 = st.columns([2.5, 1])
                with pwd_col1:
                    pwd_input_a = st.text_input(
                        "PDF Password",
                        type="password",
                        key="pwd_a_input",
                        placeholder="Enter password (e.g. secret123)",
                        label_visibility="collapsed"
                    )
                with pwd_col2:
                    if st.button("Unlock PDF", key="btn_unlock_a", type="primary", use_container_width=True):
                        if st.session_state.file_a_bytes:
                            meta_unlocked_a = extract_and_validate_pdf(
                                st.session_state.file_a_bytes,
                                filename=st.session_state.file_a_name or meta_a.filename,
                                password=pwd_input_a,
                            )
                            st.session_state.doc_a_meta = meta_unlocked_a
                            st.session_state.file_a_hash = meta_unlocked_a.content_hash
                            st.rerun()
                st.caption("💡 *Tip: For `encrypted_sample.pdf`, use password: `secret123`*")
                st.markdown("</div>", unsafe_allow_html=True)

        elif not meta_a.is_valid:
            st.error(f"❌ **Validation Error:** {meta_a.error_message}")
            if meta_a.is_scanned:
                st.info(
                    "🔍 **Scanned/Image-Only Document Detected:** This file contains 0 extractable digital characters. "
                    "The application strictly extracts text and does not pretend OCR took place without OCR models.",
                    icon="ℹ️"
                )

        else:
            # Valid document display
            st.success(f"✅ **{meta_a.filename}** &bull; Validated")
            st.markdown(
                f"""
                <div class="metric-grid">
                    <div class="metric-box">
                        <div class="metric-val">{meta_a.file_size_formatted}</div>
                        <div class="metric-lbl">Size</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-val">{meta_a.total_pages}</div>
                        <div class="metric-lbl">Pages</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-val">{meta_a.total_characters:,}</div>
                        <div class="metric-lbl">Characters</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-val">{meta_a.total_words:,}</div>
                        <div class="metric-lbl">Words</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-val">{meta_a.estimated_tokens:,}</div>
                        <div class="metric-lbl">Est. Tokens</div>
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

            # Extracted Text Inspector
            with st.expander("🔍 Inspect Extracted Text & Pages", expanded=False):
                tab_snip_a, tab_pages_a = st.tabs(["Snippet Preview", "Page Browser"])
                with tab_snip_a:
                    st.caption(meta_a.get_preview(max_chars=600))
                with tab_pages_a:
                    if meta_a.pages:
                        page_num_a = st.selectbox(
                            "Select Page to View",
                            options=range(1, len(meta_a.pages) + 1),
                            format_func=lambda p: f"Page {p} ({meta_a.pages[p-1].character_count} chars)",
                            key="page_selector_a",
                        )
                        selected_page_a = meta_a.pages[page_num_a - 1]
                        st.text_area(
                            f"Text on Page {page_num_a}",
                            value=selected_page_a.text[:2000],
                            height=180,
                            disabled=True,
                            key="txt_area_page_a",
                        )
                    else:
                        st.info("No individual pages available.")

            if meta_a.warnings:
                for w in meta_a.warnings:
                    st.warning(w, icon="⚠️")


# ------------------------------------------------------------------------------
# PANEL B: Document B (Revised / Updated)
# ------------------------------------------------------------------------------
with col_right:
    st.markdown(
        """
        <div class="card-header-row">
            <div class="card-title">📄 Document B &mdash; Revised Document</div>
            <span style="font-size: 0.8rem; color: #94A3B8;">Updated Version</span>
        </div>
        """,
        unsafe_allow_html=True,
    )

    uploaded_file_b = st.file_uploader(
        "Choose revised PDF",
        type=["pdf"],
        key=f"file_b_uploader_{st.session_state.uploader_key}",
        help="Upload the revised or modified version of the document (PDF).",
        label_visibility="collapsed",
    )

    if uploaded_file_b is not None:
        file_b_bytes = uploaded_file_b.getvalue()
        current_hash_b = hashlib.sha256(file_b_bytes).hexdigest()
        if st.session_state.file_b_hash != current_hash_b or st.session_state.doc_b_meta is None:
            st.session_state.file_b_bytes = file_b_bytes
            st.session_state.file_b_name = uploaded_file_b.name
            st.session_state.doc_b_meta = extract_and_validate_pdf(file_b_bytes, filename=uploaded_file_b.name)
            st.session_state.file_b_hash = current_hash_b
            st.session_state.comparison_result = None
            st.session_state.cached_report_bytes = None

    meta_b = st.session_state.doc_b_meta

    if meta_b:
        # Check if file is encrypted and needs password unlock
        if meta_b.is_encrypted and not meta_b.is_valid:
            st.error(f"🔒 **Password-Protected PDF:** {meta_b.error_message}")
            with st.container():
                st.markdown("<div style='background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); border-radius: 10px; padding: 1rem;'>", unsafe_allow_html=True)
                st.markdown("##### 🔓 Unlock Document B")
                pwd_col1_b, pwd_col2_b = st.columns([2.5, 1])
                with pwd_col1_b:
                    pwd_input_b = st.text_input(
                        "PDF Password",
                        type="password",
                        key="pwd_b_input",
                        placeholder="Enter password (e.g. secret123)",
                        label_visibility="collapsed"
                    )
                with pwd_col2_b:
                    if st.button("Unlock PDF", key="btn_unlock_b", type="primary", use_container_width=True):
                        if st.session_state.file_b_bytes:
                            meta_unlocked_b = extract_and_validate_pdf(
                                st.session_state.file_b_bytes,
                                filename=st.session_state.file_b_name or meta_b.filename,
                                password=pwd_input_b,
                            )
                            st.session_state.doc_b_meta = meta_unlocked_b
                            st.session_state.file_b_hash = meta_unlocked_b.content_hash
                            st.rerun()
                st.caption("💡 *Tip: For `encrypted_sample.pdf`, use password: `secret123`*")
                st.markdown("</div>", unsafe_allow_html=True)

        elif not meta_b.is_valid:
            st.error(f"❌ **Validation Error:** {meta_b.error_message}")
            if meta_b.is_scanned:
                st.info(
                    "🔍 **Scanned/Image-Only Document Detected:** This file contains 0 extractable digital characters. "
                    "The application strictly extracts text and does not pretend OCR took place without OCR models.",
                    icon="ℹ️"
                )

        else:
            # Valid document display
            st.success(f"✅ **{meta_b.filename}** &bull; Validated")
            st.markdown(
                f"""
                <div class="metric-grid">
                    <div class="metric-box">
                        <div class="metric-val">{meta_b.file_size_formatted}</div>
                        <div class="metric-lbl">Size</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-val">{meta_b.total_pages}</div>
                        <div class="metric-lbl">Pages</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-val">{meta_b.total_characters:,}</div>
                        <div class="metric-lbl">Characters</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-val">{meta_b.total_words:,}</div>
                        <div class="metric-lbl">Words</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-val">{meta_b.estimated_tokens:,}</div>
                        <div class="metric-lbl">Est. Tokens</div>
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

            # Extracted Text Inspector
            with st.expander("🔍 Inspect Extracted Text & Pages", expanded=False):
                tab_snip_b, tab_pages_b = st.tabs(["Snippet Preview", "Page Browser"])
                with tab_snip_b:
                    st.caption(meta_b.get_preview(max_chars=600))
                with tab_pages_b:
                    if meta_b.pages:
                        page_num_b = st.selectbox(
                            "Select Page to View",
                            options=range(1, len(meta_b.pages) + 1),
                            format_func=lambda p: f"Page {p} ({meta_b.pages[p-1].character_count} chars)",
                            key="page_selector_b",
                        )
                        selected_page_b = meta_b.pages[page_num_b - 1]
                        st.text_area(
                            f"Text on Page {page_num_b}",
                            value=selected_page_b.text[:2000],
                            height=180,
                            disabled=True,
                            key="txt_area_page_b",
                        )
                    else:
                        st.info("No individual pages available.")

            if meta_b.warnings:
                for w in meta_b.warnings:
                    st.warning(w, icon="⚠️")


# ==============================================================================
# Main Compare Action Bar & Live Multi-Stage AI Reasoning
# ==============================================================================

st.write("")
is_ready = bool(
    meta_a
    and meta_b
    and meta_a.is_valid
    and meta_b.is_valid
    and backend_api_key
)

col_sp1, col_action, col_sp2 = st.columns([1, 1.8, 1])

with col_action:
    compare_btn = st.button(
        "⚡ Compare Documents with Gemini AI",
        type="primary",
        disabled=not is_ready or st.session_state.is_processing,
        use_container_width=True,
    )

if not meta_a or not meta_b:
    st.markdown(
        "<div style='text-align: center; color: #64748B; font-size: 0.9rem; margin-top: 0.4rem;'>"
        "Please provide both Document A and Document B above to enable comparison."
        "</div>",
        unsafe_allow_html=True,
    )
elif meta_a and meta_b and (not meta_a.is_valid or not meta_b.is_valid):
    st.markdown(
        "<div style='text-align: center; color: #FB7185; font-size: 0.9rem; margin-top: 0.4rem;'>"
        "⚠️ One or both documents have validation issues or require a password."
        "</div>",
        unsafe_allow_html=True,
    )


# Execution of Comparison
if compare_btn and is_ready:
    st.session_state.is_processing = True
    st.session_state.comparison_error = None

    comparison_cache_key = f"{meta_a.content_hash}:{meta_b.content_hash}:{active_model}"

    # Fast cache lookup
    if comparison_cache_key in st.session_state.comparison_cache:
        st.session_state.comparison_result = st.session_state.comparison_cache[comparison_cache_key]
        st.session_state.is_processing = False
        st.rerun()

    progress_bar = st.progress(15)
    status_label = st.empty()

    try:
        status_label.markdown("⏳ **Step 1/3:** Validating page markers & calculating token budgets...")
        progress_bar.progress(30)
        time.sleep(0.3)

        text_a = meta_a.get_page_text_with_markers()
        text_b = meta_b.get_page_text_with_markers()

        status_label.markdown(f"🧠 **Step 2/3:** Analyzing both documents with **{active_model}** in a single structured schema...")
        progress_bar.progress(60)

        result = compare_documents_with_gemini(
            doc_a_filename=meta_a.filename,
            doc_a_text=text_a,
            doc_b_filename=meta_b.filename,
            doc_b_text=text_b,
            api_key=backend_api_key,
            model_name=active_model,
            doc_a_hash=meta_a.content_hash,
            doc_b_hash=meta_b.content_hash,
        )

        status_label.markdown("📊 **Step 3/3:** Synthesizing comparison matrix and building executive Word (.docx) report...")
        progress_bar.progress(90)

        docx_buf = generate_docx_report(result, meta_a, meta_b)
        st.session_state.cached_report_bytes = docx_buf.getvalue()
        st.session_state.cached_report_key = comparison_cache_key

        progress_bar.progress(100)
        status_label.markdown("✅ **Comparison Analysis Complete!**")
        time.sleep(0.4)

        st.session_state.comparison_cache[comparison_cache_key] = result
        st.session_state.comparison_result = result
        st.session_state.comparison_error = None

    except Exception as e:
        st.session_state.comparison_error = str(e)
        st.session_state.comparison_result = None
    finally:
        st.session_state.is_processing = False
        progress_bar.empty()
        status_label.empty()
        st.rerun()

if st.session_state.comparison_error:
    st.error(f"❌ Comparison Execution Error: {st.session_state.comparison_error}")


# ==============================================================================
# Executive Comparison Results Dashboard
# ==============================================================================

comp = st.session_state.comparison_result

if comp is not None and meta_a is not None and meta_b is not None:
    st.markdown("<hr style='border-color: rgba(255, 255, 255, 0.1); margin: 2.5rem 0 1.5rem 0;'>", unsafe_allow_html=True)

    # Ensure pre-generated Word report is ready
    comp_key = f"{meta_a.content_hash}:{meta_b.content_hash}:{active_model}"
    if (
        st.session_state.cached_report_bytes is None
        or st.session_state.cached_report_key != comp_key
    ):
        st.session_state.cached_report_bytes = generate_docx_report(comp, meta_a, meta_b).getvalue()
        st.session_state.cached_report_key = comp_key

    # Header row with title & Export Actions
    hdr_left, hdr_right = st.columns([2.5, 2])
    with hdr_left:
        st.markdown(
            f"""
            <div style="margin-bottom: 0.5rem;">
                <h3 style="margin-bottom: 0.2rem;">Executive Comparison Dashboard</h3>
                <span style="color: #94A3B8; font-size: 0.92rem;">
                    Baseline: <strong style="color: #E2E8F0;">{comp.document_a_summary.filename}</strong> &bull;
                    Revised: <strong style="color: #E2E8F0;">{comp.document_b_summary.filename}</strong>
                </span>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with hdr_right:
        exp_c1, exp_c2, exp_c3 = st.columns([1.5, 1.2, 1])
        with exp_c1:
            safe_a = comp.document_a_summary.filename.replace(" ", "_")[:12]
            safe_b = comp.document_b_summary.filename.replace(" ", "_")[:12]
            st.download_button(
                label="📥 Download (.docx)",
                data=st.session_state.cached_report_bytes,
                file_name=f"Comparison_Report_{safe_a}_vs_{safe_b}.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                type="primary",
                use_container_width=True,
                help="Download formatted Microsoft Word executive report.",
            )
        with exp_c2:
            json_str = comp.model_dump_json(indent=2)
            st.download_button(
                label="📊 JSON Data",
                data=json_str,
                file_name=f"Comparison_Data_{safe_a}_vs_{safe_b}.json",
                mime="application/json",
                use_container_width=True,
                help="Download structured JSON comparison payload.",
            )
        with exp_c3:
            if st.button("New", use_container_width=True, help="Clear comparison results"):
                reset_comparison()
                st.rerun()

    # Executive KPI Metric Cards
    num_added = sum(1 for d in comp.differences if d.category == "Added")
    num_modified = sum(1 for d in comp.differences if d.category == "Modified")
    num_removed = sum(1 for d in comp.differences if d.category == "Removed")
    num_conflicts = sum(1 for d in comp.differences if d.category == "Conflicting")
    total_diffs = len(comp.differences)
    total_sims = len(comp.similarities)

    st.markdown(
        f"""
        <div class="kpi-container">
            <div class="kpi-card">
                <div class="kpi-number" style="color: #6366F1;">{total_diffs}</div>
                <div class="kpi-title">Total Changes</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-number" style="color: #10B981;">{num_added}</div>
                <div class="kpi-title">Added Clauses</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-number" style="color: #F59E0B;">{num_modified}</div>
                <div class="kpi-title">Modified Terms</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-number" style="color: #F43F5E;">{num_removed}</div>
                <div class="kpi-title">Removed Rules</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-number" style="color: #8B5CF6;">{num_conflicts}</div>
                <div class="kpi-title">Conflicts</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-number" style="color: #38BDF8;">{total_sims}</div>
                <div class="kpi-title">Similarities</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-number" style="color: #A855F7;">{len(comp.key_details)}</div>
                <div class="kpi-title">Key Details</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # 7 Dedicated Results Tabs
    tab_sum_a, tab_sum_b, tab_sim, tab_diff, tab_key_details, tab_conclusion, tab_limitations = st.tabs([
        "Summary A",
        "Summary B",
        "Similarities",
        "Differences",
        "Key Details",
        "Conclusion",
        "Limitations",
    ])

    # -------------------------------------------------------------------------
    # TAB 1: Summary A
    # -------------------------------------------------------------------------
    with tab_sum_a:
        st.markdown(f"#### 📄 Document A Summary: {comp.document_a_summary.filename}")
        
        st.markdown("##### Main Purpose & Scope")
        st.markdown(
            f"""
            <div style="background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.08); padding: 1rem 1.25rem; border-radius: 10px; line-height: 1.6;">
                {comp.document_a_summary.main_purpose}
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.write("")
        col_pts, col_reqs = st.columns(2)
        with col_pts:
            st.markdown("##### 📌 Key Takeaways & Provisions")
            for pt in comp.document_a_summary.important_points:
                st.markdown(f"&bull; {pt}")

        with col_reqs:
            st.markdown("##### ⚖️ Requirements & Obligations")
            if comp.document_a_summary.key_requirements_and_conditions:
                for req in comp.document_a_summary.key_requirements_and_conditions:
                    st.markdown(f"&bull; {req}")
            else:
                st.caption("No explicit requirements listed.")

    # -------------------------------------------------------------------------
    # TAB 2: Summary B
    # -------------------------------------------------------------------------
    with tab_sum_b:
        st.markdown(f"#### 📄 Document B Summary: {comp.document_b_summary.filename}")
        
        st.markdown("##### Main Purpose & Scope")
        st.markdown(
            f"""
            <div style="background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.08); padding: 1rem 1.25rem; border-radius: 10px; line-height: 1.6;">
                {comp.document_b_summary.main_purpose}
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.write("")
        col_pts_b, col_reqs_b = st.columns(2)
        with col_pts_b:
            st.markdown("##### 📌 Key Takeaways & Provisions")
            for pt in comp.document_b_summary.important_points:
                st.markdown(f"&bull; {pt}")

        with col_reqs_b:
            st.markdown("##### ⚖️ Requirements & Obligations")
            if comp.document_b_summary.key_requirements_and_conditions:
                for req in comp.document_b_summary.key_requirements_and_conditions:
                    st.markdown(f"&bull; {req}")
            else:
                st.caption("No explicit requirements listed.")

    # -------------------------------------------------------------------------
    # TAB 3: Similarities
    # -------------------------------------------------------------------------
    with tab_sim:
        st.markdown("#### 🤝 Similarities & Common Provisions")
        st.caption("Statements, shared topics, core principles, and rules confirmed by both documents:")

        if not comp.similarities:
            st.info("No explicit shared provisions were identified between the uploaded documents.")
        else:
            for idx, item in enumerate(comp.similarities):
                with st.container():
                    st.markdown(
                        f"""
                        <div class="diff-card">
                            <div style="font-weight: 700; font-size: 1.05rem; color: #38BDF8; margin-bottom: 0.35rem;">
                                {idx + 1}. {item.topic}
                            </div>
                            <div style="color: #E2E8F0; font-size: 0.95rem; line-height: 1.5; margin-bottom: 0.75rem;">
                                {item.description}
                            </div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
                                <div class="evidence-box">
                                    <span style="font-size: 0.75rem; font-weight: 700; color: #94A3B8;">DOCUMENT A EVIDENCE</span>
                                    <div style="font-size: 0.88rem; color: #CBD5E1; margin-top: 4px;">{item.evidence_doc_a}</div>
                                </div>
                                <div class="evidence-box">
                                    <span style="font-size: 0.75rem; font-weight: 700; color: #94A3B8;">DOCUMENT B EVIDENCE</span>
                                    <div style="font-size: 0.88rem; color: #CBD5E1; margin-top: 4px;">{item.evidence_doc_b}</div>
                                </div>
                            </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

    # -------------------------------------------------------------------------
    # TAB 4: Differences (with Category Filter & Search)
    # -------------------------------------------------------------------------
    with tab_diff:
        st.markdown("#### ⚡ Meaningful Differences & Divergences")
        st.caption("Changes classified by category with verbatim citations from both documents:")

        # Search and Category Filter
        flt_col1, flt_col2 = st.columns([1.5, 2.5])
        with flt_col1:
            category_filter = st.selectbox(
                "Filter by Category",
                options=["All Categories", "Added", "Modified", "Removed", "Conflicting", "Cannot Be Compared Reliably"],
                key="diff_filter_category",
            )
        with flt_col2:
            search_query = st.text_input(
                "Search Changes",
                placeholder="Search by keyword, clause, or term...",
                key="diff_search_box",
            )

        # Filter items
        filtered_diffs = comp.differences
        if category_filter != "All Categories":
            filtered_diffs = [d for d in filtered_diffs if d.category.lower() == category_filter.lower()]
        if search_query.strip():
            sq = search_query.lower()
            filtered_diffs = [
                d for d in filtered_diffs
                if (sq in d.title.lower() or sq in d.description.lower() or sq in d.doc_a_state.lower() or sq in d.doc_b_state.lower())
            ]

        if not filtered_diffs:
            st.info("No differences match the selected filter criteria.")
        else:
            for diff in filtered_diffs:
                badge_class = {
                    "Added": "badge-added",
                    "Removed": "badge-removed",
                    "Modified": "badge-modified",
                    "Conflicting": "badge-conflicting",
                    "Cannot Be Compared Reliably": "badge-uncertain",
                }.get(diff.category, "badge-uncertain")

                st.markdown(
                    f"""
                    <div class="diff-card">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
                            <div style="display: flex; align-items: center; gap: 0.6rem;">
                                <span class="badge-diff {badge_class}">{diff.category}</span>
                                <strong style="font-size: 1.08rem; color: #F8FAFC;">{diff.title}</strong>
                            </div>
                        </div>
                        <div style="color: #CBD5E1; font-size: 0.95rem; line-height: 1.5; margin-bottom: 0.85rem;">
                            {diff.description}
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
                            <div class="evidence-box">
                                <span style="font-size: 0.75rem; font-weight: 700; color: #94A3B8;">DOCUMENT A STATE</span>
                                <div style="font-size: 0.88rem; color: #F1F5F9; margin-top: 4px;">{diff.doc_a_state}</div>
                                <div class="evidence-citation">&bull; Citation: {diff.evidence_doc_a}</div>
                            </div>
                            <div class="evidence-box">
                                <span style="font-size: 0.75rem; font-weight: 700; color: #94A3B8;">DOCUMENT B STATE</span>
                                <div style="font-size: 0.88rem; color: #F1F5F9; margin-top: 4px;">{diff.doc_b_state}</div>
                                <div class="evidence-citation">&bull; Citation: {diff.evidence_doc_b}</div>
                            </div>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

    # -------------------------------------------------------------------------
    # TAB 5: Key Details Matrix Table
    # -------------------------------------------------------------------------
    with tab_key_details:
        st.markdown("#### 📊 Key Details Comparison Matrix")
        st.caption("Direct side-by-side verification of dates, amounts, allowances, stipends, and security requirements:")

        if not comp.key_details:
            st.info("No specific verifiable key details were extracted.")
        else:
            table_rows = []
            for item in comp.key_details:
                table_rows.append({
                    "Parameter": item.detail,
                    "Document A": item.document_a,
                    "Document B": item.document_b,
                    "Change or Observation": item.change_or_observation,
                    "Verifiable Evidence": item.evidence,
                })
            df_details = pd.DataFrame(table_rows)

            st.dataframe(
                df_details,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "Parameter": st.column_config.TextColumn("Parameter", width="medium"),
                    "Document A": st.column_config.TextColumn("Document A", width="medium"),
                    "Document B": st.column_config.TextColumn("Document B", width="medium"),
                    "Change or Observation": st.column_config.TextColumn("Change / Observation", width="large"),
                    "Verifiable Evidence": st.column_config.TextColumn("Citation / Evidence", width="large"),
                },
            )

    # -------------------------------------------------------------------------
    # TAB 6: Conclusion
    # -------------------------------------------------------------------------
    with tab_conclusion:
        st.markdown("#### 🏛️ Executive Conclusion & Synthesis")
        st.markdown(
            f"""
            <div style="background: rgba(99, 102, 241, 0.08); border-left: 4px solid #6366F1; padding: 1.4rem; border-radius: 4px 12px 12px 4px; font-size: 1.05rem; line-height: 1.65; color: #F1F5F9;">
                {comp.overall_conclusion}
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.write("")
        st.markdown("##### Audit Metrics")
        ca1, ca2, ca3, ca4 = st.columns(4)
        ca1.metric("Comparison Model", comp.model_used)
        ca2.metric("Timestamp", comp.comparison_timestamp)
        ca3.metric("Document A Pages", meta_a.total_pages)
        ca4.metric("Document B Pages", meta_b.total_pages)

    # -------------------------------------------------------------------------
    # TAB 7: Limitations & Audit
    # -------------------------------------------------------------------------
    with tab_limitations:
        st.markdown("#### ⚠️ Processing Limitations & Document Audit")
        if comp.limitations:
            for lim in comp.limitations:
                st.info(f"&bull; {lim}")
        else:
            st.success("No document truncation, unreadable pages, or processing anomalies were identified.")

        st.markdown(
            f"""
            <div class="alert-callout" style="border-left-color: #F59E0B; background: rgba(245, 158, 11, 0.08);">
                <div style="font-weight: 700; color: #FBBF24; margin-bottom: 0.35rem;">INFORMATIONAL SCOPE & LEGAL DISCLAIMER</div>
                <div style="font-size: 0.88rem; color: #E2E8F0; line-height: 1.5;">
                    {comp.legal_disclaimer}
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        # Technical payload expander for viva defense and auditing
        with st.expander("🛠️ View Raw JSON Structured Payload", expanded=False):
            st.json(comp.model_dump())


# Legal Notice Footer
st.markdown(
    """
    <div class="disclaimer-text">
        AI Document Comparison Assistant &bull; Built with Google Gemini 3.5 API, Streamlit, and python-docx.<br>
        Informational comparison assistant. This tool does not provide legal advice or certify statutory compliance.
    </div>
    """,
    unsafe_allow_html=True,
)
